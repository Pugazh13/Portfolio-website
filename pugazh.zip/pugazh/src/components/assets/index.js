import photo from "./photo.jpeg";
import linkedin from "./linkedin.png";
import arrow from "./arrow.png";
import checkmark from "./checkmark.png";
import buddypro from "./buddypro.png";
import email from "./email.png";
import education from "./education.png";
import github from "./github.png";
import instagram from "./instagram.png";
import ITG from "./ITG.png";

export {
  photo,
  linkedin,
  arrow,
  email,
  buddypro,
  checkmark,
  github,
  education,
  instagram,
  ITG,
};
